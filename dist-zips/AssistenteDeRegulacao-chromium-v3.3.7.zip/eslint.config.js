// ESLint Configuration for Assistente de Regulação Médica
export { default } from './config/eslint/eslint.config.js';
