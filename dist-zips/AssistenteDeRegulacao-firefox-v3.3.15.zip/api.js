﻿import "./browser-polyfill.js";
import { CONFIG, getAPIConfig } from "./config.js";
import { getBrowserAPIInstance } from "./BrowserAPI.js";
import {
  API_ENDPOINTS,
  API_PARAMS,
  API_HEADERS,
  API_ERROR_MESSAGES,
  API_UTILS,
  API_VALIDATIONS,
  REGULATION_FILTERS,
  PRONTUARIO_PARAMS,
  DATA_FORMATS,
  HTTP_STATUS,
} from "./api-constants.js";
import { parseConsultasHTML } from "./consultation-parser.js";

const api = getBrowserAPIInstance();

// âœ… TASK-A-002: Error Boundaries e Circuit Breaker Pattern
class CircuitBreaker {
  constructor(threshold = 5, timeout = 60000, resetTimeout = 30000) {
    this.threshold = threshold; // NÃºmero de falhas antes de abrir o circuito
    this.timeout = timeout; // Timeout para requisiÃ§Ãµes
    this.resetTimeout = resetTimeout; // Tempo para tentar fechar o circuito
    this.failureCount = 0;
    this.lastFailureTime = null;
    this.state = 'CLOSED'; // CLOSED, OPEN, HALF_OPEN
  }

  async execute(operation, operationName = 'API Operation') {
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastFailureTime > this.resetTimeout) {
        this.state = 'HALF_OPEN';
        logger.info(`[Circuit Breaker] Tentando fechar circuito para ${operationName}`);
      } else {
        const error = new Error(`Circuit breaker is OPEN for ${operationName}`);
        error.circuitBreakerOpen = true;
        throw error;
      }
    }

    try {
      const result = await Promise.race([
        operation(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error(`Timeout after ${this.timeout}ms`)), this.timeout)
        )
      ]);

      // Sucesso - reset do circuit breaker
      if (this.state === 'HALF_OPEN') {
        this.state = 'CLOSED';
        this.failureCount = 0;
        logger.info(`[Circuit Breaker] Circuito fechado para ${operationName}`);
      }

      return result;
    } catch (error) {
      this.failureCount++;
      this.lastFailureTime = Date.now();

      if (this.failureCount >= this.threshold) {
        this.state = 'OPEN';
        logger.error(`[Circuit Breaker] Circuito aberto para ${operationName} apÃ³s ${this.failureCount} falhas`);
      }

      throw error;
    }
  }

  getState() {
    return {
      state: this.state,
      failureCount: this.failureCount,
      lastFailureTime: this.lastFailureTime
    };
  }
}

// âœ… TASK-A-002: Retry Logic com Backoff Exponencial
class RetryHandler {
  constructor(maxRetries = 3, baseDelay = 1000, maxDelay = 10000) {
    this.maxRetries = maxRetries;
    this.baseDelay = baseDelay;
    this.maxDelay = maxDelay;
  }

  async execute(operation, operationName = 'API Operation') {
    let lastError;
    
    for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error;
        
        // NÃ£o fazer retry para erros que nÃ£o sÃ£o temporÃ¡rios
        if (this.isNonRetryableError(error)) {
          logger.error(`[Retry Handler] Erro nÃ£o recuperÃ¡vel em ${operationName}:`, error.message);
          throw error;
        }

        if (attempt === this.maxRetries) {
          logger.error(`[Retry Handler] Falha final em ${operationName} apÃ³s ${this.maxRetries + 1} tentativas`);
          break;
        }

        const delay = Math.min(
          this.baseDelay * Math.pow(2, attempt),
          this.maxDelay
        );
        
        logger.warn(`[Retry Handler] Tentativa ${attempt + 1}/${this.maxRetries + 1} falhou para ${operationName}, tentando novamente em ${delay}ms:`, error.message);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    
    throw lastError;
  }

  isNonRetryableError(error) {
    // Erros que nÃ£o devem ser retentados
    if (error.circuitBreakerOpen) return true;
    if (error.message.includes('URL_BASE_NOT_CONFIGURED')) return true;
    if (error.message.includes('invÃ¡lido')) return true;
    if (error.message.includes('necessÃ¡rio')) return true;
    
    // CÃ³digos HTTP que nÃ£o devem ser retentados
    if (error.status) {
      const nonRetryableStatuses = [400, 401, 403, 404, 422];
      return nonRetryableStatuses.includes(error.status);
    }
    
    return false;
  }
}

// âœ… TASK-A-002: Logging Estruturado para Erros
class ErrorLogger {
  static log(error, context = {}) {
    const timestamp = new Date().toISOString();
    const errorInfo = {
      timestamp,
      message: error.message,
      stack: error.stack,
      name: error.name,
      context,
      userAgent: navigator.userAgent,
      url: window.location?.href || 'extension-context'
    };

    // Log estruturado no console
    logger.error(`[API Error] ${timestamp}:`, errorInfo);

    // Salvar no storage para debugging (Ãºltimos 50 erros)
    this.saveToStorage(errorInfo).catch(storageError => {
      logger.warn('[Error Logger] Falha ao salvar erro no storage:', storageError);
    });
  }

  static async saveToStorage(errorInfo) {
    try {
      const stored = await api.storage.local.get({ apiErrors: [] });
      const errors = stored.apiErrors || [];
      
      // Manter apenas os Ãºltimos 50 erros
      errors.unshift(errorInfo);
      if (errors.length > 50) {
        errors.splice(50);
      }
      
      await api.storage.local.set({ apiErrors: errors });
    } catch (error) {
      // Falha silenciosa para nÃ£o criar loop de erros
    }
  }

  static async getStoredErrors() {
    try {
      const stored = await api.storage.local.get({ apiErrors: [] });
      return stored.apiErrors || [];
    } catch (error) {
      logger.warn('[Error Logger] Falha ao recuperar erros do storage:', error);
      return [];
    }
  }

  static async clearStoredErrors() {
    try {
      await api.storage.local.remove('apiErrors');
      logger.info('[Error Logger] Erros armazenados limpos');
    } catch (error) {
      logger.warn('[Error Logger] Falha ao limpar erros do storage:', error);
    }
  }
}

// âœ… TASK-A-002: Wrapper para OperaÃ§Ãµes de API com Error Boundaries
class APIErrorBoundary {
  constructor() {
    this.circuitBreaker = new CircuitBreaker();
    this.retryHandler = new RetryHandler();
  }

  async execute(operation, operationName = 'API Operation', options = {}) {
    const {
      enableRetry = true,
      enableCircuitBreaker = true,
      fallback = null,
      context = {}
    } = options;

    try {
      const wrappedOperation = async () => {
        if (enableRetry) {
          return await this.retryHandler.execute(operation, operationName);
        } else {
          return await operation();
        }
      };

      if (enableCircuitBreaker) {
        return await this.circuitBreaker.execute(wrappedOperation, operationName);
      } else {
        return await wrappedOperation();
      }
    } catch (error) {
      // Log estruturado do erro
      ErrorLogger.log(error, {
        operationName,
        context,
        circuitBreakerState: this.circuitBreaker.getState()
      });

      // Tentar fallback se disponÃ­vel
      if (fallback && typeof fallback === 'function') {
        try {
          logger.warn(`[API Error Boundary] Usando fallback para ${operationName}`);
          return await fallback();
        } catch (fallbackError) {
          ErrorLogger.log(fallbackError, {
            operationName: `${operationName} (fallback)`,
            context
          });
          throw fallbackError;
        }
      }

      // Re-throw o erro original se nÃ£o hÃ¡ fallback
      throw error;
    }
  }

  getCircuitBreakerState() {
    return this.circuitBreaker.getState();
  }
}

// âœ… TASK-A-006: Rate Limiting System
class TokenBucket {
  constructor(capacity = 10, refillRate = 2, refillInterval = 1000) {
    this.capacity = capacity; // MÃ¡ximo de tokens
    this.tokens = capacity; // Tokens atuais
    this.refillRate = refillRate; // Tokens adicionados por intervalo
    this.refillInterval = refillInterval; // Intervalo em ms
    this.lastRefill = Date.now();
    
    // Auto-refill tokens
    this.refillTimer = setInterval(() => {
      this.refill();
    }, this.refillInterval);
  }

  refill() {
    const now = Date.now();
    const timePassed = now - this.lastRefill;
    const tokensToAdd = Math.floor((timePassed / this.refillInterval) * this.refillRate);
    
    if (tokensToAdd > 0) {
      this.tokens = Math.min(this.capacity, this.tokens + tokensToAdd);
      this.lastRefill = now;
    }
  }

  consume(tokens = 1) {
    this.refill(); // Atualiza tokens antes de consumir
    
    if (this.tokens >= tokens) {
      this.tokens -= tokens;
      return true;
    }
    return false;
  }

  getAvailableTokens() {
    this.refill();
    return this.tokens;
  }

  getWaitTime(tokens = 1) {
    this.refill();
    
    if (this.tokens >= tokens) {
      return 0;
    }
    
    const tokensNeeded = tokens - this.tokens;
    const timeNeeded = Math.ceil(tokensNeeded / this.refillRate) * this.refillInterval;
    return timeNeeded;
  }

  destroy() {
    if (this.refillTimer) {
      clearInterval(this.refillTimer);
      this.refillTimer = null;
    }
  }
}

class RequestQueue {
  constructor(maxSize = 100) {
    this.queue = [];
    this.maxSize = maxSize;
    this.processing = false;
  }

  enqueue(request) {
    if (this.queue.length >= this.maxSize) {
      throw new Error(`Request queue is full (max: ${this.maxSize})`);
    }
    
    return new Promise((resolve, reject) => {
      this.queue.push({
        request,
        resolve,
        reject,
        timestamp: Date.now()
      });
      
      this.processQueue();
    });
  }

  async processQueue() {
    if (this.processing || this.queue.length === 0) {
      return;
    }
    
    this.processing = true;
    
    while (this.queue.length > 0) {
      const item = this.queue.shift();
      
      try {
        const result = await item.request();
        item.resolve(result);
      } catch (error) {
        item.reject(error);
      }
      
      // Pequeno delay entre processamentos
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    
    this.processing = false;
  }

  getQueueSize() {
    return this.queue.length;
  }

  clear() {
    this.queue.forEach(item => {
      item.reject(new Error('Queue cleared'));
    });
    this.queue = [];
  }
}

class APICache {
  constructor(defaultTTL = 300000) { // 5 minutos default
    this.cache = new Map();
    this.defaultTTL = defaultTTL;
    
    // Limpeza automÃ¡tica a cada 5 minutos
    this.cleanupTimer = setInterval(() => {
      this.cleanup();
    }, 300000);
  }

  generateKey(url, options = {}) {
    const keyData = {
      url: url.toString(),
      method: options.method || 'GET',
      body: options.body || '',
      headers: JSON.stringify(options.headers || {})
    };
    
    return btoa(JSON.stringify(keyData)).replace(/[^a-zA-Z0-9]/g, '');
  }

  set(key, value, ttl = this.defaultTTL) {
    const expiresAt = Date.now() + ttl;
    this.cache.set(key, {
      value,
      expiresAt,
      createdAt: Date.now()
    });
  }

  get(key) {
    const item = this.cache.get(key);
    
    if (!item) {
      return null;
    }
    
    if (Date.now() > item.expiresAt) {
      this.cache.delete(key);
      return null;
    }
    
    return item.value;
  }

  has(key) {
    return this.get(key) !== null;
  }

  delete(key) {
    return this.cache.delete(key);
  }

  cleanup() {
    const now = Date.now();
    let cleaned = 0;
    
    for (const [key, item] of this.cache.entries()) {
      if (now > item.expiresAt) {
        this.cache.delete(key);
        cleaned++;
      }
    }
    
    if (cleaned > 0) {
      logger.info(`[API Cache] Limpeza automÃ¡tica: ${cleaned} itens removidos`);
    }
  }

  clear() {
    this.cache.clear();
  }

  getStats() {
    const now = Date.now();
    let valid = 0;
    let expired = 0;
    
    for (const [key, item] of this.cache.entries()) {
      if (now > item.expiresAt) {
        expired++;
      } else {
        valid++;
      }
    }
    
    return {
      total: this.cache.size,
      valid,
      expired,
      hitRate: this.hitCount / (this.hitCount + this.missCount) || 0
    };
  }

  destroy() {
    if (this.cleanupTimer) {
      clearInterval(this.cleanupTimer);
      this.cleanupTimer = null;
    }
    this.clear();
  }
}

class RateLimitMonitor {
  constructor() {
    this.metrics = {
      totalRequests: 0,
      rateLimitedRequests: 0,
      cacheHits: 0,
      cacheMisses: 0,
      averageWaitTime: 0,
      queuedRequests: 0,
      errors: 0
    };
    
    this.requestTimes = [];
    this.maxHistorySize = 1000;
  }

  recordRequest(waitTime = 0, fromCache = false, error = false) {
    this.metrics.totalRequests++;
    
    if (waitTime > 0) {
      this.metrics.rateLimitedRequests++;
    }
    
    if (fromCache) {
      this.metrics.cacheHits++;
    } else {
      this.metrics.cacheMisses++;
    }
    
    if (error) {
      this.metrics.errors++;
    }
    
    this.requestTimes.push({
      timestamp: Date.now(),
      waitTime,
      fromCache,
      error
    });
    
    // Manter apenas os Ãºltimos registros
    if (this.requestTimes.length > this.maxHistorySize) {
      this.requestTimes.splice(0, this.requestTimes.length - this.maxHistorySize);
    }
    
    // Calcular tempo mÃ©dio de espera
    const totalWaitTime = this.requestTimes.reduce((sum, req) => sum + req.waitTime, 0);
    this.metrics.averageWaitTime = totalWaitTime / this.requestTimes.length;
  }

  recordQueueSize(size) {
    this.metrics.queuedRequests = size;
  }

  getMetrics() {
    return {
      ...this.metrics,
      cacheHitRate: this.metrics.cacheHits / (this.metrics.cacheHits + this.metrics.cacheMisses) || 0,
      errorRate: this.metrics.errors / this.metrics.totalRequests || 0,
      rateLimitRate: this.metrics.rateLimitedRequests / this.metrics.totalRequests || 0
    };
  }

  getRecentActivity(minutes = 5) {
    const cutoff = Date.now() - (minutes * 60 * 1000);
    return this.requestTimes.filter(req => req.timestamp > cutoff);
  }

  reset() {
    this.metrics = {
      totalRequests: 0,
      rateLimitedRequests: 0,
      cacheHits: 0,
      cacheMisses: 0,
      averageWaitTime: 0,
      queuedRequests: 0,
      errors: 0
    };
    this.requestTimes = [];
  }
}

class RateLimiter {
  constructor(options = {}) {
    const {
      tokensPerSecond = 2,
      burstCapacity = 10,
      queueMaxSize = 100,
      cacheDefaultTTL = 300000, // 5 minutos
      enableCache = true,
      enableQueue = true
    } = options;
    
    this.tokenBucket = new TokenBucket(burstCapacity, tokensPerSecond, 1000);
    this.requestQueue = enableQueue ? new RequestQueue(queueMaxSize) : null;
    this.cache = enableCache ? new APICache(cacheDefaultTTL) : null;
    this.monitor = new RateLimitMonitor();
    this.enableCache = enableCache;
    this.enableQueue = enableQueue;
  }

  async execute(url, options = {}, cacheOptions = {}) {
    const startTime = Date.now();
    let fromCache = false;
    let waitTime = 0;
    
    try {
      // Verificar cache primeiro
      if (this.enableCache && this.cache) {
        const cacheKey = this.cache.generateKey(url, options);
        const cachedResult = this.cache.get(cacheKey);
        
        if (cachedResult) {
          fromCache = true;
          this.monitor.recordRequest(0, true, false);
          logger.info(`[Rate Limiter] Cache hit para ${url}`);
          return cachedResult;
        }
      }
      
      // FunÃ§Ã£o de requisiÃ§Ã£o
      const makeRequest = async () => {
        // Verificar tokens disponÃ­veis
        if (!this.tokenBucket.consume(1)) {
          waitTime = this.tokenBucket.getWaitTime(1);
          
          if (waitTime > 0) {
            logger.info(`[Rate Limiter] Aguardando ${waitTime}ms para ${url}`);
            await new Promise(resolve => setTimeout(resolve, waitTime));
            
            // Tentar consumir novamente apÃ³s espera
            if (!this.tokenBucket.consume(1)) {
              throw new Error('Rate limit exceeded after waiting');
            }
          }
        }
        
        // Fazer a requisiÃ§Ã£o
        const response = await fetch(url, options);
        
        // Verificar se a resposta Ã© JSON para cache
        let result;
        const contentType = response.headers.get('content-type');
        
        if (contentType && contentType.includes('application/json')) {
          result = await response.clone().json();
        } else {
          result = response;
        }
        
        // Armazenar no cache se habilitado
        if (this.enableCache && this.cache && response.ok) {
          const cacheKey = this.cache.generateKey(url, options);
          const ttl = cacheOptions.ttl || this.cache.defaultTTL;
          
          // SÃ³ cachear respostas JSON
          if (contentType && contentType.includes('application/json')) {
            this.cache.set(cacheKey, result, ttl);
            logger.info(`[Rate Limiter] Resultado cacheado para ${url} (TTL: ${ttl}ms)`);
          }
        }
        
        return result;
      };
      
      // Executar com ou sem queue
      let result;
      if (this.enableQueue && this.requestQueue) {
        this.monitor.recordQueueSize(this.requestQueue.getQueueSize());
        result = await this.requestQueue.enqueue(makeRequest);
      } else {
        result = await makeRequest();
      }
      
      this.monitor.recordRequest(waitTime, fromCache, false);
      return result;
      
    } catch (error) {
      this.monitor.recordRequest(waitTime, fromCache, true);
      throw error;
    }
  }

  getMetrics() {
    const baseMetrics = this.monitor.getMetrics();
    
    return {
      ...baseMetrics,
      tokenBucket: {
        availableTokens: this.tokenBucket.getAvailableTokens(),
        capacity: this.tokenBucket.capacity,
        refillRate: this.tokenBucket.refillRate
      },
      queue: this.requestQueue ? {
        size: this.requestQueue.getQueueSize(),
        maxSize: this.requestQueue.maxSize
      } : null,
      cache: this.cache ? this.cache.getStats() : null
    };
  }

  clearCache() {
    if (this.cache) {
      this.cache.clear();
      logger.info('[Rate Limiter] Cache limpo');
    }
  }

  resetMetrics() {
    this.monitor.reset();
    logger.info('[Rate Limiter] MÃ©tricas resetadas');
  }

  destroy() {
    if (this.tokenBucket) {
      this.tokenBucket.destroy();
    }
    
    if (this.requestQueue) {
      this.requestQueue.clear();
    }
    
    if (this.cache) {
      this.cache.destroy();
    }
    
    logger.info('[Rate Limiter] DestruÃ­do');
  }
}

// InstÃ¢ncia global do Rate Limiter
const rateLimiter = new RateLimiter({
  tokensPerSecond: 2, // 2 requisiÃ§Ãµes por segundo
  burstCapacity: 10, // AtÃ© 10 requisiÃ§Ãµes em burst
  queueMaxSize: 50, // MÃ¡ximo 50 requisiÃ§Ãµes na fila
  cacheDefaultTTL: 300000, // Cache de 5 minutos
  enableCache: true,
  enableQueue: true
});

// InstÃ¢ncia global do Error Boundary
const apiErrorBoundary = new APIErrorBoundary();

// âœ… TASK-A-002: FunÃ§Ã£o helper para criar fallbacks
function createFallback(defaultValue, operationName) {
  return () => {
    logger.warn(`[Fallback] Retornando valor padrÃ£o para ${operationName}`);
    return Promise.resolve(defaultValue);
  };
}

// âœ… TASK-A-006: Wrapper para fetch com rate limiting
async function rateLimitedFetch(url, options = {}, cacheOptions = {}) {
  try {
    return await rateLimiter.execute(url, options, cacheOptions);
  } catch (error) {
    logger.error(`[Rate Limited Fetch] Erro para ${url}:`, error);
    throw error;
  }
}

// Default configuration for batched API requests
const DEFAULT_BATCH_CONFIG = {
  ATTACHMENT_BATCH_SIZE: CONFIG.API.BATCH_SIZE, // Process 5 attachments at a time
  BATCH_DELAY_MS: CONFIG.API.BATCH_DELAY_MS, // 100ms delay between batches
};

/**
 * Gets the current batch configuration from storage or returns defaults.
 * @returns {Promise<object>} The batch configuration object
 */
async function getBatchConfig() {
  try {
    const stored = await api.storage.sync.get({
      batchAttachmentSize: DEFAULT_BATCH_CONFIG.ATTACHMENT_BATCH_SIZE,
      batchDelayMs: DEFAULT_BATCH_CONFIG.BATCH_DELAY_MS,
    });

    return {
      ATTACHMENT_BATCH_SIZE: Math.max(
        1,
        parseInt(stored.batchAttachmentSize, 10) ||
          DEFAULT_BATCH_CONFIG.ATTACHMENT_BATCH_SIZE
      ),
      BATCH_DELAY_MS: Math.max(
        0,
        parseInt(stored.batchDelayMs, 10) || DEFAULT_BATCH_CONFIG.BATCH_DELAY_MS
      ),
    };
  } catch (error) {
    logger.warn("Failed to load batch configuration, using defaults:", error);
    return DEFAULT_BATCH_CONFIG;
  }
}

/**
 * Processes an array of items in batches to prevent overwhelming the server.
 * This utility function implements rate limiting for API requests by:
 * - Processing items in configurable batch sizes
 * - Adding delays between batches to reduce server load
 * - Handling individual item failures gracefully
 * - Implementing timeout and retry logic for robustness
 *
 * Used to replace Promise.all() calls that could create too many concurrent requests.
 *
 * @param {Array} items - Array of items to process
 * @param {Function} processor - Async function to process each item
 * @param {number} batchSize - Number of items to process per batch
 * @param {number} delayMs - Delay in milliseconds between batches
 * @returns {Promise<Array>} Array of processed results
 */
async function processBatched(
  items,
  processor,
  batchSize = CONFIG.API.BATCH_SIZE,
  delayMs = CONFIG.API.BATCH_DELAY_MS
) {
  const results = [];
  const maxRetries = 3;
  const batchTimeout = 30000; // 30 segundos timeout por lote

  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    let retryCount = 0;
    
    while (retryCount < maxRetries) {
      try {
        // âœ… SEGURO: Implementar timeout para cada lote
        const batchResults = await Promise.race([
          Promise.all(
            batch.map(async (item, index) => {
              try {
                return await processor(item, i + index);
              } catch (error) {
                logger.warn(`Batch processing error for item ${i + index}:`, error);
                return null; // Return null for failed items
              }
            })
          ),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Batch timeout')), batchTimeout)
          )
        ]);
        
        results.push(...batchResults);
        break; // Sucesso, sair do loop de retry
        
      } catch (error) {
        retryCount++;
        logger.warn(`Lote ${i} falhou (tentativa ${retryCount}/${maxRetries}):`, error.message);
        
        if (retryCount === maxRetries) {
          logger.error(`Lote ${i} falhou apÃ³s ${maxRetries} tentativas, preenchendo com nulls`);
          // Preenche com nulls para manter Ã­ndices consistentes
          results.push(...batch.map(() => null));
        } else {
          // Delay exponencial entre tentativas
          const retryDelay = delayMs * Math.pow(2, retryCount - 1);
          await new Promise(resolve => setTimeout(resolve, retryDelay));
        }
      }
    }

    // Add delay between batches (except for the last batch)
    if (i + batchSize < items.length && delayMs > 0) {
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }

  return results;
}

/**
 * ObtÃ©m a URL base do sistema a partir das configuraÃ§Ãµes salvas pelo usuÃ¡rio.
 * @returns {Promise<string>} A URL base salva.
 */
export async function getBaseUrl() {
  let data;
  try {
    data = await api.storage.sync.get("baseUrl");
  } catch (e) {
    logger.error("Erro ao obter a URL base do storage:", e);
    throw e;
  }

  if (data && data.baseUrl) {
    return data.baseUrl;
  }

  logger.error("URL base nÃ£o configurada. VÃ¡ em 'OpÃ§Ãµes' para configurÃ¡-la.");
  throw new Error("URL_BASE_NOT_CONFIGURED");
}

/**
 * Lida com erros de fetch de forma centralizada.
 * @param {Response} response - O objeto de resposta do fetch.
 */
function handleFetchError(response) {
  logger.error(
    `Erro na requisiÃ§Ã£o: ${response.status} ${response.statusText}`
  );
  throw new Error("Falha na comunicaÃ§Ã£o com o servidor.");
}

/**
 * Extrai o texto de uma string HTML.
 * @param {string} htmlString - A string HTML.
 * @returns {string} O texto extraÃ­do.
 */
function getTextFromHTML(htmlString) {
  if (!htmlString) return "";
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlString, "text/html");
  return doc.body.textContent || "";
}

/**
 * Busca as configuraÃ§Ãµes de prioridade de regulaÃ§Ã£o do sistema.
 * @returns {Promise<Array<object>>} Uma lista de objetos de prioridade.
 */
export async function fetchRegulationPriorities() {
  return await apiErrorBoundary.execute(
    async () => {
      const baseUrl = await getBaseUrl();
      const url = API_UTILS.buildUrl(baseUrl, API_ENDPOINTS.REGULATION_PRIORITIES);

      // âœ… TASK-A-006: Rate limiting aplicado
      const data = await rateLimitedFetch(url, {}, { ttl: 600000 }); // Cache por 10 minutos
      
      // Filtra apenas as ativas e ordena pela ordem de exibiÃ§Ã£o definida no sistema
      return data
        .filter((p) => p.coreIsAtivo === "t")
        .sort((a, b) => a.coreOrdemExibicao - b.coreOrdemExibicao);
    },
    'fetchRegulationPriorities',
    {
      fallback: createFallback([], 'fetchRegulationPriorities'),
      context: { endpoint: API_ENDPOINTS.REGULATION_PRIORITIES }
    }
  );
}

/**
 * Busca os detalhes completos de uma regulaÃ§Ã£o especÃ­fica.
 * @param {object} params
 * @param {string} params.reguIdp - O IDP da regulaÃ§Ã£o.
 * @param {string} params.reguIds - O IDS da regulaÃ§Ã£o.
 * @returns {Promise<object>} O objeto com os dados da regulaÃ§Ã£o.
 */
export async function fetchRegulationDetails({ reguIdp, reguIds }) {
  if (!API_VALIDATIONS.isValidRegulationId(reguIdp, reguIds)) {
    throw new Error(API_ERROR_MESSAGES.MISSING_REGULATION_ID);
  }
  
  const baseUrl = await getBaseUrl();
  const url = new URL(API_UTILS.buildUrl(baseUrl, API_ENDPOINTS.REGULATION_DETAILS));
  url.search = new URLSearchParams({
    "reguPK.idp": reguIdp,
    "reguPK.ids": reguIds,
  }).toString();

  const response = await fetch(url, {
    method: "GET",
    headers: API_HEADERS.AJAX,
  });

  if (!response.ok) {
    handleFetchError(response);
    return null;
  }

  if (!API_VALIDATIONS.isJsonResponse(response)) {
    throw new Error(API_ERROR_MESSAGES.INVALID_RESPONSE);
  }

  const data = await response.json();
  // O objeto de dados estÃ¡ aninhado sob a chave "regulacao"
  return data.regulacao || null;
}


// âœ… SEGURANÃ‡A: Import estÃ¡tico para evitar dynamic imports inseguros
import { validateSearchTerm, sanitizeSearchTerm, validateCPF, validateCNS } from "./validation.js";

export async function searchPatients(term) {
  // Early exit for empty terms
  if (!term || term.length < 1) return [];

  return await apiErrorBoundary.execute(
    async () => {
      // Validate and sanitize the search term
      const validation = validateSearchTerm(term);
      if (!validation.valid) {
        throw new Error(API_ERROR_MESSAGES.INVALID_SEARCH_TERM);
      }

      const sanitizedTerm = sanitizeSearchTerm(term);
      if (!sanitizedTerm) {
        throw new Error("Search term cannot be empty after sanitization");
      }

      const baseUrl = await getBaseUrl();
      const url = new URL(API_UTILS.buildUrl(baseUrl, API_ENDPOINTS.PATIENT_SEARCH));
      url.search = new URLSearchParams({ searchString: sanitizedTerm });
      
      // âœ… TASK-A-006: Rate limiting aplicado com cache curto para buscas
      const data = await rateLimitedFetch(url, {
        headers: API_HEADERS.AJAX,
      }, { ttl: 60000 }); // Cache por 1 minuto para buscas
      
      return Array.isArray(data)
        ? data.map((p) => ({
            idp: p[0],
            ids: p[1],
            value: p[5],
            cns: p[6],
            dataNascimento: p[7],
            cpf: p[15],
          }))
        : [];
    },
    'searchPatients',
    {
      fallback: createFallback([], 'searchPatients'),
      context: { searchTerm: term?.substring(0, 10) + '...' }
    }
  );
}

export async function fetchVisualizaUsuario({ idp, ids }) {
  if (!API_VALIDATIONS.isValidRegulationId(idp, ids)) {
    throw new Error(`ID invÃ¡lido. idp: '${idp}', ids: '${ids}'.`);
  }
  
  const baseUrl = await getBaseUrl();
  const url = API_UTILS.buildUrl(baseUrl, API_ENDPOINTS.PATIENT_DETAILS);
  const body = `isenPK.idp=${encodeURIComponent(idp)}&isenPK.ids=${encodeURIComponent(ids)}`;
  
  const response = await fetch(url, {
    method: "POST",
    headers: API_HEADERS.FORM,
    body,
  });
  
  if (!response.ok) handleFetchError(response);

  if (!API_VALIDATIONS.isJsonResponse(response)) {
    logger.error(API_ERROR_MESSAGES.INVALID_RESPONSE);
    throw new Error(API_ERROR_MESSAGES.SESSION_EXPIRED);
  }

  const patientData = await response.json();
  return patientData?.usuarioServico || {};
}

export async function fetchProntuarioHash({
  isenFullPKCrypto,
  dataInicial,
  dataFinal,
}) {
  if (!isenFullPKCrypto) {
    throw new Error("ID criptografado necessÃ¡rio.");
  }

  const baseUrl = await getBaseUrl();
  const url = API_UTILS.buildUrl(baseUrl, API_ENDPOINTS.PARAM_HASH);
  
  const paramString = API_UTILS.buildProntuarioParamString({
    isenFullPKCrypto,
    dataInicial,
    dataFinal,
  });

  const response = await fetch(url, {
    method: "POST",
    headers: API_HEADERS.FORM,
    body: `paramString=${paramString}`,
  });

  if (!response.ok) {
    throw new Error(API_ERROR_MESSAGES.HASH_GENERATION_FAILED);
  }

  const data = await response.json();
  if (data?.string) return data.string;
  throw new Error(data.mensagem || "Resposta nÃ£o continha o hash.");
}

export async function fetchConsultasEspecializadas({
  isenFullPKCrypto,
  dataInicial,
  dataFinal,
}) {
  if (!isenFullPKCrypto) throw new Error("ID criptografado necessÃ¡rio.");
  const baseUrl = await getBaseUrl();
  const url = new URL(
    `${baseUrl}/sigss/prontuarioAmbulatorial2/buscaDadosConsultaEspecializadas_HTML`
  );
  url.search = new URLSearchParams({
    isenFullPKCrypto,
    dataInicial,
    dataFinal,
  });
  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });
  if (!response.ok) handleFetchError(response);
  const data = await response.json();
  return {
    htmlData: data?.tabela || "",
    jsonData: parseConsultasHTML(data?.tabela || ""),
  };
}

export async function fetchConsultasBasicas({
  isenFullPKCrypto,
  dataInicial,
  dataFinal,
}) {
  if (!isenFullPKCrypto) throw new Error("ID criptografado necessÃ¡rio.");
  const baseUrl = await getBaseUrl();
  const url = new URL(
    `${baseUrl}/sigss/prontuarioAmbulatorial2/buscaDadosConsulta_HTML`
  );
  url.search = new URLSearchParams({
    isenFullPKCrypto,
    dataInicial,
    dataFinal,
  });
  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });
  if (!response.ok) handleFetchError(response);
  const data = await response.json();
  return {
    htmlData: data?.tabela || "",
    jsonData: parseConsultasHTML(data?.tabela || ""),
  };
}

export async function fetchAllConsultations({
  isenFullPKCrypto,
  dataInicial,
  dataFinal,
}) {
  const [basicasResult, especializadasResult] = await Promise.all([
    fetchConsultasBasicas({ isenFullPKCrypto, dataInicial, dataFinal }),
    fetchConsultasEspecializadas({ isenFullPKCrypto, dataInicial, dataFinal }),
  ]);
  const combinedJsonData = [
    ...basicasResult.jsonData,
    ...especializadasResult.jsonData,
  ];
  const combinedHtmlData = `<h3>Consultas BÃ¡sicas</h3>${basicasResult.htmlData}<h3>Consultas Especializadas</h3>${especializadasResult.htmlData}`;
  return { jsonData: combinedJsonData, htmlData: combinedHtmlData };
}

export async function fetchExamesSolicitados({
  isenPK,
  dataInicial,
  dataFinal,
  comResultado,
  semResultado,
}) {
  if (!isenPK) throw new Error("ID (isenPK) do paciente Ã© necessÃ¡rio.");
  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/exameRequisitado/findAllReex`);
  const params = {
    "filters[0]": `dataInicial:${dataInicial}`,
    "filters[1]": `dataFinal:${dataFinal}`,
    "filters[2]": `isenPK:${isenPK}`,
    exameSolicitadoMin: "true",
    exameSolicitadoOutro: "true",
    exameComResultado: comResultado,
    exameSemResultado: semResultado,
    tipoBusca: "reex",
    _search: "false",
    nd: Date.now(),
    rows: String(CONFIG.API.MAX_ROWS),
    page: "1",
    sidx: "reex.reexData",
    sord: "asc",
  };
  url.search = new URLSearchParams(params).toString();
  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });
  if (!response.ok) handleFetchError(response);
  const data = await response.json();
  return (data?.rows || []).map((row) => {
    const cell = row.cell || [];
    return {
      id: row.id || "",
      date: cell[2] || "",
      examName: (cell[5] || "").trim(),
      hasResult: (cell[6] || "") === "SIM",
      professional: cell[8] || "",
      specialty: cell[9] || "",
      resultIdp: cell[13] != null ? String(cell[13]) : "",
      resultIds: cell[14] != null ? String(cell[14]) : "",
    };
  });
}

export async function fetchResultadoExame({ idp, ids }) {
  if (!idp || !ids)
    throw new Error("IDs do resultado do exame sÃ£o necessÃ¡rios.");
  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/resultadoExame/visualizaImagem`);
  url.search = new URLSearchParams({
    "iterPK.idp": idp,
    "iterPK.ids": ids,
  }).toString();
  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });
  if (!response.ok) handleFetchError(response);
  const data = await response.json();
  return data?.path || null;
}

export async function fetchCadsusData({ cpf, cns, skipValidation = false }) {
  if (!cpf && !cns) {
    return null;
  }

  return await apiErrorBoundary.execute(
    async () => {
      // SÃ³ validar se nÃ£o for uma busca interna (quando skipValidation for false)
      if (!skipValidation) {
        // âœ… SEGURANÃ‡A: Usando imports estÃ¡ticos jÃ¡ disponÃ­veis no topo do arquivo

        // Validate CPF if provided
        if (cpf) {
          const cpfValidation = validateCPF(cpf);
          if (!cpfValidation.valid) {
            throw new Error(`CPF invÃ¡lido: ${cpfValidation.message}`);
          }
        }

        // Validate CNS if provided
        if (cns) {
          const cnsValidation = validateCNS(cns);
          if (!cnsValidation.valid) {
            throw new Error(`CNS invÃ¡lido: ${cnsValidation.message}`);
          }
        }
      }

      const baseUrl = await getBaseUrl();
      const url = new URL(API_UTILS.buildUrl(baseUrl, API_ENDPOINTS.CADSUS_SEARCH));

      const params = API_UTILS.buildCadsusParams({ cpf, cns });
      url.search = params.toString();

      const response = await fetch(url, {
        headers: API_HEADERS.AJAX,
      });

      if (!response.ok) {
        const error = new Error(API_ERROR_MESSAGES.CADSUS_SEARCH_FAILED);
        error.status = response.status;
        throw error;
      }

      const data = await response.json();

      if (data && data.rows && data.rows.length > 0) {
        return data.rows[0].cell;
      }

      return null;
    },
    'fetchCadsusData',
    {
      fallback: createFallback(null, 'fetchCadsusData'),
      context: { cpf: cpf ? '***' : null, cns: cns ? '***' : null }
    }
  );
}

export async function fetchAppointmentDetails({ idp, ids }) {
  if (!idp || !ids) throw new Error("ID do agendamento Ã© necessÃ¡rio.");
  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/agendamentoConsulta/visualiza`);
  url.search = new URLSearchParams({
    "agcoPK.idp": idp,
    "agcoPK.ids": ids,
  }).toString();

  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });

  if (!response.ok) {
    logger.error(`Falha ao buscar detalhes do agendamento ${idp}-${ids}`);
    return null;
  }
  const data = await response.json();
  return data?.agendamentoConsulta || null;
}

/**
 * NEW: Busca os detalhes de um agendamento de exame.
 * @param {object} params
 * @param {string} params.idp - O IDP do agendamento de exame.
 * @param {string} params.ids - O IDS do agendamento de exame.
 * @returns {Promise<object>} O objeto com os dados do agendamento de exame.
 */
export async function fetchExamAppointmentDetails({ idp, ids }) {
  if (!idp || !ids) throw new Error("ID do agendamento de exame Ã© necessÃ¡rio.");
  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/agendamentoExame/visualizar`);
  url.search = new URLSearchParams({
    "examPK.idp": idp,
    "examPK.ids": ids,
  }).toString();

  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });

  if (!response.ok) {
    handleFetchError(response);
    return null;
  }
  const data = await response.json();
  return data?.agendamentoExame || null;
}

export async function fetchAppointments({ isenPK, dataInicial, dataFinal }) {
  if (!isenPK) throw new Error("ID (isenPK) do paciente Ã© necessÃ¡rio.");
  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/resumoCompromisso/lista`);
  const params = {
    isenPK,
    dataInicial,
    dataFinal,
    _search: "false",
    nd: Date.now(),
    rows: String(CONFIG.API.MAX_ROWS),
    page: "1",
    sidx: "data",
    sord: "desc",
  };
  url.search = new URLSearchParams(params).toString();

  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });

  if (!response.ok) handleFetchError(response);
  const data = await response.json();

  const basicAppointments = (data?.rows || []).map((row) => {
    const cell = row.cell || [];
    let status = "AGENDADO";
    if (String(cell[10]).includes("red")) status = "FALTOU";
    else if (String(cell[7]).includes("blue")) status = "PRESENTE";
    else if (String(cell[8]).includes("red")) status = "CANCELADO";
    else if (String(cell[11]).includes("blue")) status = "ATENDIDO";

    return {
      id: row.id || "",
      type: cell[1] || "N/A",
      date: cell[2] || "",
      time: cell[3] || "",
      location: cell[4] || "",
      professional: cell[5] || "",
      description: (cell[6] || "").trim(),
      status: status,
    };
  });

  // Get current batch configuration for appointments
  const batchConfig = await getBatchConfig();

  // Process appointment enrichment in batches to prevent overwhelming the server
  const enrichedAppointments = await processBatched(
    basicAppointments,
    async (appt) => {
      if (appt.type.toUpperCase().includes("EXAME")) {
        // CORREÃ‡ÃƒO: O ID de agendamentos de exame vem no formato "EXAM-IDP-IDS".
        // A lÃ³gica posterior (renderizadores) espera "IDP-IDS".
        // Normalizamos o ID aqui para garantir consistÃªncia.
        const parts = (appt.id || "").split("-");
        if (parts.length === 3 && parts[0].toUpperCase() === "EXAM") {
          // ReconstrÃ³i o appt com o ID normalizado.
          return {
            ...appt,
            id: `${parts[1]}-${parts[2]}`,
            specialty: appt.description || "Exame sem descriÃ§Ã£o",
          };
        }
        return {
          ...appt,
          specialty: appt.description || "Exame sem descriÃ§Ã£o",
        };
      }

      const [idp, ids] = appt.id.split("-");
      if (!idp || !ids) return appt;

      try {
        const details = await fetchAppointmentDetails({ idp, ids });
        if (details) {
          let specialtyString = "Sem especialidade";
          const apcn = details.atividadeProfissionalCnes;

          if (apcn && apcn.apcnNome) {
            specialtyString = apcn.apcnCod
              ? `${apcn.apcnNome} (${apcn.apcnCod})`
              : apcn.apcnNome;
          }

          return {
            ...appt,
            isSpecialized: details.agcoIsEspecializada === "t",
            isOdonto: details.agcoIsOdonto === "t",
            specialty: specialtyString,
          };
        }
      } catch (error) {
        logger.warn(
          `Falha ao buscar detalhes para o agendamento ${appt.id}`,
          error
        );
      }
      return appt;
    },
    batchConfig.ATTACHMENT_BATCH_SIZE,
    batchConfig.BATCH_DELAY_MS
  );

  return enrichedAppointments;
}

async function fetchRegulations({
  isenPK,
  modalidade,
  dataInicial,
  dataFinal,
}) {
  if (!isenPK) throw new Error("ID (isenPK) do paciente Ã© necessÃ¡rio.");
  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/regulacaoRegulador/lista`);

  const params = {
    "filters[0]": `isFiltrarData:${!!dataInicial}`,
    "filters[1]": `dataInicial:${dataInicial || ""}`,
    "filters[2]": `dataFinal:${dataFinal || ""}`,
    "filters[3]": `modalidade:${modalidade}`,
    "filters[4]": "solicitante:undefined",
    "filters[5]": `usuarioServico:${isenPK}`,
    "filters[6]": "autorizado:true",
    "filters[7]": "pendente:true",
    "filters[8]": "devolvido:true",
    "filters[9]": "negado:true",
    "filters[10]": "emAnalise:true",
    "filters[11]": "cancelados:true",
    "filters[12]": "cboFiltro:",
    "filters[13]": "procedimentoFiltro:",
    "filters[14]": "reguGravidade:",
    "filters[15]": "reguIsRetorno:...",
    "filters[16]": "codBarProtocolo:",
    "filters[17]": "reguIsAgendadoFiltro:todos",
    _search: "false",
    nd: Date.now(),
    rows: String(CONFIG.API.MAX_ROWS),
    page: "1",
    sidx: "regu.reguDataPrevista",
    sord: "desc",
  };

  url.search = new URLSearchParams(params).toString();

  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });

  if (!response.ok) handleFetchError(response);
  const data = await response.json();

  return (data?.rows || []).map((row) => {
    const cell = row.cell || [];
    let idp = null,
      ids = null;
    const idMatch = (row.id || "").match(/reguPK(\d+)-(\d+)/);
    if (idMatch && idMatch.length === 3) {
      idp = idMatch[1];
      ids = idMatch[2];
    }

    const descriptionHtml = cell[6] || "";
    const [procedure, cid] = descriptionHtml.split("<br/>");

    return {
      id: row.id,
      idp,
      ids,
      type: cell[2] || "N/A",
      priority: getTextFromHTML(cell[3]),
      date: cell[4] || "",
      status: getTextFromHTML(cell[5]),
      procedure: getTextFromHTML(procedure),
      cid: cid ? cid.trim() : "",
      requester: cell[7] || "",
      provider: cell[8] || "",
      isenFullPKCrypto: cell[9] || "",
    };
  });
}

export async function fetchAllRegulations({
  isenPK,
  dataInicial,
  dataFinal,
  type = "all",
}) {
  let regulationsToFetch = [];

  if (type === "all") {
    regulationsToFetch = await Promise.all([
      fetchRegulations({ isenPK, modalidade: "ENC", dataInicial, dataFinal }),
      fetchRegulations({ isenPK, modalidade: "EXA", dataInicial, dataFinal }),
    ]);
  } else if (type === "ENC") {
    regulationsToFetch = [
      await fetchRegulations({
        isenPK,
        modalidade: "ENC",
        dataInicial,
        dataFinal,
      }),
    ];
  } else if (type === "EXA") {
    regulationsToFetch = [
      await fetchRegulations({
        isenPK,
        modalidade: "EXA",
        dataInicial,
        dataFinal,
      }),
    ];
  }

  const allRegulations = regulationsToFetch.flat();

  // Get current batch configuration
  const batchConfig = await getBatchConfig();

  // Process attachment fetching in batches to prevent overwhelming the server
  const regulationsWithAttachments = await processBatched(
    allRegulations,
    async (regulation) => {
      if (regulation.idp && regulation.ids) {
        try {
          // CORREÃ‡ÃƒO: Usa o ID da prÃ³pria regulaÃ§Ã£o como o isenPK para esta chamada especÃ­fica.
          const attachmentIsenPk = `${regulation.idp}-${regulation.ids}`;
          const attachments = await fetchRegulationAttachments({
            reguIdp: regulation.idp,
            reguIds: regulation.ids,
            isenPK: attachmentIsenPk,
          });
          return { ...regulation, attachments };
        } catch (error) {
          logger.warn(
            `Falha ao buscar anexos para regulaÃ§Ã£o ${regulation.id}:`,
            error
          );
          return { ...regulation, attachments: [] };
        }
      }
      return { ...regulation, attachments: [] };
    },
    batchConfig.ATTACHMENT_BATCH_SIZE,
    batchConfig.BATCH_DELAY_MS
  );

  regulationsWithAttachments.sort((a, b) => {
    const dateA = a.date.split("/").reverse().join("-");
    const dateB = b.date.split("/").reverse().join("-");
    return new Date(dateB) - new Date(dateA);
  });

  return regulationsWithAttachments;
}

/**
 * Busca a lista de documentos anexados ao cadastro de um paciente.
 * @param {object} params
 * @param {string} params.isenPK - O PK do paciente no formato "idp-ids".
 * @returns {Promise<Array<object>>} Uma lista de objetos de documento.
 */
export async function fetchDocuments({ isenPK }) {
  if (!isenPK) throw new Error("ID (isenPK) do paciente Ã© necessÃ¡rio.");
  const [idp, ids] = isenPK.split("-");
  if (!idp || !ids)
    throw new Error("ID (isenPK) do paciente em formato invÃ¡lido.");

  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/isar/buscaGrid`);
  const params = {
    "isenPK.idp": idp,
    "isenPK.ids": ids,
    _search: "false",
    nd: Date.now(),
    rows: String(CONFIG.API.MAX_ROWS_REGULATIONS),
    page: "1",
    sidx: "isar.isarData desc, isar.isarPK.idp",
    sord: "desc",
  };
  url.search = new URLSearchParams(params).toString();

  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });

  if (!response.ok) handleFetchError(response);
  const data = await response.json();

  return (data?.rows || []).map((row) => {
    const cell = row.cell || [];
    return {
      idp: cell[0],
      ids: cell[1],
      date: cell[2] || "",
      description: (cell[3] || "").trim(),
      fileType: (cell[4] || "").toLowerCase(),
    };
  });
}

/**
 * ObtÃ©m a URL de visualizaÃ§Ã£o para um documento especÃ­fico.
 * @param {object} params
 * @param {string} params.idp - O IDP do documento.
 * @param {string} params.ids - O IDS do documento.
 * @returns {Promise<string|null>} A URL completa para visualizaÃ§Ã£o do arquivo.
 */
export async function fetchDocumentUrl({ idp, ids }) {
  if (!idp || !ids) throw new Error("IDs do documento sÃ£o necessÃ¡rios.");

  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/isar/getHashArquivo`);
  url.search = new URLSearchParams({
    "isarPK.idp": idp,
    "isarPK.ids": ids,
  }).toString();

  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });

  if (!response.ok) handleFetchError(response);
  const data = await response.json();

  if (data?.isenArquivo?.img) {
    const filePath = data.isenArquivo.img;
    return filePath.startsWith("http") ? filePath : `${baseUrl}${filePath}`;
  }

  return null;
}

/**
 * Busca a lista de arquivos anexados a uma solicitaÃ§Ã£o de regulaÃ§Ã£o especÃ­fica.
 * @param {object} params
 * @param {string} params.reguIdp - O IDP da regulaÃ§Ã£o.
 * @param {string} params.reguIds - O IDS da regulaÃ§Ã£o.
 * @param {string} params.isenPK - O PK do paciente no formato "idp-ids".
 * @returns {Promise<Array<object>>} Uma lista de objetos de anexo.
 */
export async function fetchRegulationAttachments({ reguIdp, reguIds, isenPK }) {
  if (!reguIdp || !reguIds) throw new Error("ID da regulaÃ§Ã£o Ã© necessÃ¡rio.");
  if (!isenPK) throw new Error("ID do paciente (isenPK) Ã© necessÃ¡rio.");

  const [isenIdp, isenIds] = isenPK.split("-");
  if (!isenIdp || !isenIds)
    throw new Error("ID do paciente (isenPK) em formato invÃ¡lido.");

  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/rear/buscaGrid`);
  const params = {
    "isenPK.idp": isenIdp,
    "isenPK.ids": isenIds,
    "reguPK.idp": reguIdp,
    "reguPK.ids": reguIds,
    _search: "false",
    nd: Date.now(),
    rows: String(CONFIG.API.MAX_ROWS_REGULATIONS),
    page: "1",
    sidx: "", // Corrigido para corresponder Ã  requisiÃ§Ã£o da aplicaÃ§Ã£o
    sord: "asc", // Corrigido para corresponder Ã  requisiÃ§Ã£o da aplicaÃ§Ã£o
  };
  url.search = new URLSearchParams(params).toString();

  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });

  if (!response.ok) handleFetchError(response);
  const data = await response.json();

  return (data?.rows || []).map((row) => {
    const cell = row.cell || [];
    return {
      idp: cell[0],
      ids: cell[1],
      date: cell[2] || "",
      description: (cell[3] || "").trim(),
      fileType: (cell[4] || "").toLowerCase(),
    };
  });
}

/**
 * ObtÃ©m a URL de visualizaÃ§Ã£o para um anexo de regulaÃ§Ã£o especÃ­fico.
 * @param {object} params
 * @param {string} params.idp - O IDP do anexo (rearPK.idp).
 * @param {string} params.ids - O IDS do anexo (rearPK.ids).
 * @returns {Promise<string|null>} A URL completa para visualizaÃ§Ã£o do arquivo.
 */
export async function fetchRegulationAttachmentUrl({ idp, ids }) {
  if (!idp || !ids) throw new Error("IDs do anexo sÃ£o necessÃ¡rios.");

  const baseUrl = await getBaseUrl();
  const url = new URL(`${baseUrl}/sigss/rear/getHashArquivo`);
  url.search = new URLSearchParams({
    "rearPK.idp": idp,
    "rearPK.ids": ids,
  }).toString();

  const response = await fetch(url, {
    headers: {
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
    },
  });

  if (!response.ok) handleFetchError(response);
  const data = await response.json();

  if (data?.regulacaoArquivo?.img) {
    const filePath = data.regulacaoArquivo.img;
    return filePath.startsWith("http") ? filePath : `${baseUrl}${filePath}`;
  }

  return null;
}

/**
 * Fetches all data sources for the patient timeline concurrently.
 * @param {object} params - The parameters for the API calls.
 * @returns {Promise<object>} An object containing the data from all sources.
 */
export async function fetchAllTimelineData({
  isenPK,
  isenFullPKCrypto,
  dataInicial,
  dataFinal,
}) {
  // Usando um objeto de promessas para tornar a extraÃ§Ã£o de resultados mais robusta.
  const dataPromises = {
    consultations: fetchAllConsultations({
      isenFullPKCrypto,
      dataInicial,
      dataFinal,
    }),
    exams: fetchExamesSolicitados({
      isenPK,
      dataInicial,
      dataFinal,
      comResultado: true,
      semResultado: true,
    }),
    appointments: fetchAppointments({ isenPK, dataInicial, dataFinal }),
    regulations: fetchAllRegulations({
      isenPK,
      dataInicial,
      dataFinal,
      type: "all",
    }),
    documents: fetchDocuments({ isenPK }),
  };

  const results = await Promise.allSettled(Object.values(dataPromises));
  const dataKeys = Object.keys(dataPromises);

  const getValueOrDefault = (result, defaultValue = []) => {
    if (result.status === "fulfilled") {
      if (result.value && typeof result.value.jsonData !== "undefined") {
        return result.value.jsonData; // For consultations
      }
      return result.value; // For others
    }
    logger.warn("Falha em chamada de API para a timeline:", result.reason);
    return defaultValue;
  };

  const timelineData = {};
  dataKeys.forEach((key, index) => {
    timelineData[key] = getValueOrDefault(results[index]);
  });

  return timelineData;
}

/**
 * Envia uma requisiÃ§Ã£o para manter a sessÃ£o ativa no sistema.
 * @returns {Promise<boolean>} True se a requisiÃ§Ã£o foi bem-sucedida, false caso contrÃ¡rio.
 */
export async function keepSessionAlive() {
  return await apiErrorBoundary.execute(
    async () => {
      const baseUrl = await getBaseUrl();
      const url = API_UTILS.buildUrl(baseUrl, API_ENDPOINTS.SYSTEM_DATETIME);

      const response = await fetch(url, {
        method: "GET",
        headers: API_HEADERS.KEEP_ALIVE,
        cache: "no-cache",
      });

      if (!response.ok) {
        // Se for erro 401 ou 403, provavelmente a sessÃ£o expirou
        if (response.status === HTTP_STATUS.UNAUTHORIZED || response.status === HTTP_STATUS.FORBIDDEN) {
          const error = new Error("SessÃ£o expirou - keep-alive nÃ£o pode manter a sessÃ£o ativa");
          error.status = response.status;
          throw error;
        }

        const error = new Error(`${API_ERROR_MESSAGES.KEEP_ALIVE_FAILED} com status ${response.status} - ${response.statusText}`);
        error.status = response.status;
        throw error;
      }

      if (!API_VALIDATIONS.isJsonResponse(response)) {
        throw new Error(API_ERROR_MESSAGES.KEEP_ALIVE_NOT_JSON);
      }

      const data = await response.json();

      // Verifica se a resposta contÃ©m dados vÃ¡lidos
      // A resposta pode ser um objeto com propriedades ou uma string direta
      if (data) {
        // Se for um objeto com propriedades especÃ­ficas
        if (typeof data === 'object' && (data.dataHora || data.data || data.hora)) {
          logger.info(`SessÃ£o mantida ativa: ${data.dataHora || data.data || "OK"}`);
          return true;
        }
        // Se for uma string direta com data/hora (formato ISO ou similar)
        else if (typeof data === 'string' && data.trim().length > 0) {
          logger.info(`SessÃ£o mantida ativa: ${data}`);
          return true;
        }
        // Se for qualquer outro valor nÃ£o-nulo/nÃ£o-vazio
        else if (data !== null && data !== undefined && data !== '') {
          logger.info(`SessÃ£o mantida ativa: ${JSON.stringify(data)}`);
          return true;
        }
      }
      
      throw new Error(API_ERROR_MESSAGES.KEEP_ALIVE_INVALID_RESPONSE);
    },
    'keepSessionAlive',
    {
      fallback: createFallback(false, 'keepSessionAlive'),
      context: { endpoint: API_ENDPOINTS.SYSTEM_DATETIME }
    }
  );
}

// âœ… TASK-A-002: FunÃ§Ãµes de Debugging e Monitoramento
/**
 * ObtÃ©m os erros armazenados para debugging.
 * @returns {Promise<Array>} Lista dos Ãºltimos erros de API
 */
export async function getAPIErrors() {
  return await ErrorLogger.getStoredErrors();
}

/**
 * Limpa os erros armazenados.
 * @returns {Promise<void>}
 */
export async function clearAPIErrors() {
  return await ErrorLogger.clearStoredErrors();
}

/**
 * ObtÃ©m o estado atual do Circuit Breaker.
 * @returns {object} Estado do circuit breaker
 */
export function getCircuitBreakerState() {
  return apiErrorBoundary.getCircuitBreakerState();
}

/**
 * ForÃ§a o reset do Circuit Breaker (para debugging).
 * @returns {void}
 */
export function resetCircuitBreaker() {
  apiErrorBoundary.circuitBreaker.state = 'CLOSED';
  apiErrorBoundary.circuitBreaker.failureCount = 0;
  apiErrorBoundary.circuitBreaker.lastFailureTime = null;
  logger.info('[Circuit Breaker] Reset manual executado');
}

// âœ… TASK-A-006: FunÃ§Ãµes de Monitoramento de Rate Limiting
/**
 * ObtÃ©m as mÃ©tricas atuais do rate limiter.
 * @returns {object} MÃ©tricas detalhadas do rate limiting
 */
export function getRateLimitMetrics() {
  return rateLimiter.getMetrics();
}

/**
 * ObtÃ©m a atividade recente do rate limiter.
 * @param {number} minutes - NÃºmero de minutos para buscar atividade (padrÃ£o: 5)
 * @returns {Array} Lista de requisiÃ§Ãµes recentes
 */
export function getRateLimitActivity(minutes = 5) {
  return rateLimiter.monitor.getRecentActivity(minutes);
}

/**
 * Limpa o cache do rate limiter.
 * @returns {void}
 */
export function clearRateLimitCache() {
  rateLimiter.clearCache();
}

/**
 * Reseta as mÃ©tricas do rate limiter.
 * @returns {void}
 */
export function resetRateLimitMetrics() {
  rateLimiter.resetMetrics();
}

/**
 * ObtÃ©m o status atual do token bucket.
 * @returns {object} Status do token bucket
 */
export function getTokenBucketStatus() {
  return {
    availableTokens: rateLimiter.tokenBucket.getAvailableTokens(),
    capacity: rateLimiter.tokenBucket.capacity,
    refillRate: rateLimiter.tokenBucket.refillRate,
    waitTimeForNextToken: rateLimiter.tokenBucket.getWaitTime(1)
  };
}

/**
 * ObtÃ©m o status atual da fila de requisiÃ§Ãµes.
 * @returns {object} Status da fila
 */
export function getRequestQueueStatus() {
  if (!rateLimiter.requestQueue) {
    return { enabled: false };
  }
  
  return {
    enabled: true,
    currentSize: rateLimiter.requestQueue.getQueueSize(),
    maxSize: rateLimiter.requestQueue.maxSize,
    processing: rateLimiter.requestQueue.processing
  };
}

/**
 * ObtÃ©m estatÃ­sticas detalhadas do cache.
 * @returns {object} EstatÃ­sticas do cache
 */
export function getCacheStats() {
  if (!rateLimiter.cache) {
    return { enabled: false };
  }
  
  return {
    enabled: true,
    ...rateLimiter.cache.getStats(),
    defaultTTL: rateLimiter.cache.defaultTTL
  };
}

/**
 * ForÃ§a a limpeza do cache expirado.
 * @returns {void}
 */
export function cleanupExpiredCache() {
  if (rateLimiter.cache) {
    rateLimiter.cache.cleanup();
  }
}

/**
 * ObtÃ©m um relatÃ³rio completo do sistema de rate limiting.
 * @returns {object} RelatÃ³rio completo
 */
export function getRateLimitReport() {
  const metrics = getRateLimitMetrics();
  const tokenBucket = getTokenBucketStatus();
  const queue = getRequestQueueStatus();
  const cache = getCacheStats();
  const recentActivity = getRateLimitActivity(10); // Ãšltimos 10 minutos
  
  return {
    timestamp: new Date().toISOString(),
    summary: {
      totalRequests: metrics.totalRequests,
      cacheHitRate: metrics.cacheHitRate,
      errorRate: metrics.errorRate,
      rateLimitRate: metrics.rateLimitRate,
      averageWaitTime: metrics.averageWaitTime
    },
    tokenBucket,
    queue,
    cache,
    recentActivity: {
      count: recentActivity.length,
      requests: recentActivity.slice(-10) // Ãšltimas 10 requisiÃ§Ãµes
    },
    recommendations: generateRateLimitRecommendations(metrics, tokenBucket, queue, cache)
  };
}

/**
 * Gera recomendaÃ§Ãµes baseadas nas mÃ©tricas atuais.
 * @param {object} metrics - MÃ©tricas do rate limiter
 * @param {object} tokenBucket - Status do token bucket
 * @param {object} queue - Status da fila
 * @param {object} cache - Status do cache
 * @returns {Array} Lista de recomendaÃ§Ãµes
 */
function generateRateLimitRecommendations(metrics, tokenBucket, queue, cache) {
  const recommendations = [];
  
  // AnÃ¡lise de rate limiting
  if (metrics.rateLimitRate > 0.3) {
    recommendations.push({
      type: 'warning',
      category: 'rate_limit',
      message: `Taxa de rate limiting alta (${(metrics.rateLimitRate * 100).toFixed(1)}%). Considere aumentar a capacidade do token bucket.`,
      action: 'increase_capacity'
    });
  }
  
  // AnÃ¡lise de cache
  if (cache.enabled && metrics.cacheHitRate < 0.5) {
    recommendations.push({
      type: 'info',
      category: 'cache',
      message: `Taxa de cache hit baixa (${(metrics.cacheHitRate * 100).toFixed(1)}%). Considere aumentar o TTL do cache.`,
      action: 'increase_ttl'
    });
  }
  
  // AnÃ¡lise de erros
  if (metrics.errorRate > 0.1) {
    recommendations.push({
      type: 'error',
      category: 'errors',
      message: `Taxa de erro alta (${(metrics.errorRate * 100).toFixed(1)}%). Verifique a conectividade e saÃºde do servidor.`,
      action: 'check_server_health'
    });
  }
  
  // AnÃ¡lise da fila
  if (queue.enabled && queue.currentSize > queue.maxSize * 0.8) {
    recommendations.push({
      type: 'warning',
      category: 'queue',
      message: `Fila de requisiÃ§Ãµes quase cheia (${queue.currentSize}/${queue.maxSize}). Considere aumentar o tamanho da fila.`,
      action: 'increase_queue_size'
    });
  }
  
  // AnÃ¡lise de tokens
  if (tokenBucket.availableTokens < tokenBucket.capacity * 0.2) {
    recommendations.push({
      type: 'info',
      category: 'tokens',
      message: `Poucos tokens disponÃ­veis (${tokenBucket.availableTokens}/${tokenBucket.capacity}). Sistema sob carga.`,
      action: 'monitor_load'
    });
  }
  
  return recommendations;
}

/**
 * Configura o rate limiter com novos parÃ¢metros.
 * @param {object} config - Nova configuraÃ§Ã£o
 * @returns {void}
 */
export function configureRateLimiter(config = {}) {
  const {
    tokensPerSecond,
    burstCapacity,
    queueMaxSize,
    cacheDefaultTTL
  } = config;
  
  logger.info('[Rate Limiter] Reconfigurando com:', config);
  
  // Destruir instÃ¢ncia atual
  rateLimiter.destroy();
  
  // Criar nova instÃ¢ncia com configuraÃ§Ã£o atualizada
  const newConfig = {
    tokensPerSecond: tokensPerSecond || 2,
    burstCapacity: burstCapacity || 10,
    queueMaxSize: queueMaxSize || 50,
    cacheDefaultTTL: cacheDefaultTTL || 300000,
    enableCache: true,
    enableQueue: true
  };
  
  // Substituir instÃ¢ncia global
  Object.assign(rateLimiter, new RateLimiter(newConfig));
  
  logger.info('[Rate Limiter] ReconfiguraÃ§Ã£o concluÃ­da');
}

/**
 * Salva as mÃ©tricas atuais no storage para anÃ¡lise posterior.
 * @returns {Promise<void>}
 */
export async function saveRateLimitMetrics() {
  try {
    const report = getRateLimitReport();
    const stored = await api.storage.local.get({ rateLimitHistory: [] });
    const history = stored.rateLimitHistory || [];
    
    // Manter apenas os Ãºltimos 100 relatÃ³rios
    history.unshift(report);
    if (history.length > 100) {
      history.splice(100);
    }
    
    await api.storage.local.set({ rateLimitHistory: history });
    logger.info('[Rate Limiter] MÃ©tricas salvas no storage');
  } catch (error) {
    logger.warn('[Rate Limiter] Falha ao salvar mÃ©tricas:', error);
  }
}

/**
 * ObtÃ©m o histÃ³rico de mÃ©tricas salvas.
 * @returns {Promise<Array>} HistÃ³rico de mÃ©tricas
 */
export async function getRateLimitHistory() {
  try {
    const stored = await api.storage.local.get({ rateLimitHistory: [] });
    return stored.rateLimitHistory || [];
  } catch (error) {
    logger.warn('[Rate Limiter] Falha ao recuperar histÃ³rico:', error);
    return [];
  }
}

/**
 * Limpa o histÃ³rico de mÃ©tricas.
 * @returns {Promise<void>}
 */
export async function clearRateLimitHistory() {
  try {
    await api.storage.local.remove('rateLimitHistory');
    logger.info('[Rate Limiter] HistÃ³rico de mÃ©tricas limpo');
  } catch (error) {
    logger.warn('[Rate Limiter] Falha ao limpar histÃ³rico:', error);
  }
}

