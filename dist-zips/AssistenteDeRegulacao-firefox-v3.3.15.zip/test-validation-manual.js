/**
 * Teste manual da validação de CNS
 * Para verificar se a implementação está funcionando corretamente
 */

// Mock simples do CONFIG
global.CONFIG = {
  TIMEOUTS: {
    DEBOUNCE_SEARCH: 300
  }
};

// Importa a função de validação
import { validateCNS } from './validation.js';

console.log('🧪 Iniciando testes manuais de validação de CNS...\n');

// Testes básicos
console.log('📋 Testes básicos:');
console.log('CNS vazio:', validateCNS(''));
console.log('CNS com 14 dígitos:', validateCNS('12345678901234'));
console.log('CNS que inicia com 3:', validateCNS('312345678901234'));
console.log('CNS com todos dígitos iguais:', validateCNS('111111111111111'));

console.log('\n📋 Testes CNS definitivo:');
console.log('CNS definitivo válido tipo 1:', validateCNS('100000000000700'));
console.log('CNS definitivo válido tipo 2:', validateCNS('200000000000300'));
console.log('CNS definitivo válido (variação):', validateCNS('123456789010000'));
console.log('CNS definitivo inválido:', validateCNS('100000000000701'));

console.log('\n📋 Testes CNS provisório:');
console.log('CNS provisório tipo 7:', validateCNS('712345678901234'));
console.log('CNS provisório tipo 8:', validateCNS('812345678901234'));
console.log('CNS provisório tipo 9 válido:', validateCNS('912345678901239'));
console.log('CNS provisório tipo 9 inválido:', validateCNS('912345678901235'));

console.log('\n📋 Testes de sequências reservadas:');
console.log('CNS tipo 7 sequência reservada:', validateCNS('700000000000000'));
console.log('CNS tipo 8 sequência reservada:', validateCNS('800000000000000'));
console.log('CNS tipo 9 sequência reservada:', validateCNS('900000000000000'));

console.log('\n📋 Testes de casos especiais:');
console.log('CNS com formatação (espaços):', validateCNS('1 0000 0000 0007 00'));
console.log('CNS definitivo caso especial (0001):', validateCNS('298765432100001'));

console.log('\n⚡ Teste de performance:');
const start = performance.now();
for (let i = 0; i < 1000; i++) {
  validateCNS('100000000000700');
}
const end = performance.now();
console.log(`1000 validações executadas em ${(end - start).toFixed(2)}ms`);
console.log(`Média por validação: ${((end - start) / 1000).toFixed(3)}ms`);

console.log('\n📊 Teste de cache:');
const cacheStart = performance.now();
for (let i = 0; i < 100; i++) {
  validateCNS('100000000000700'); // Mesmo CNS para testar cache
}
const cacheEnd = performance.now();
console.log(`100 validações com cache em ${(cacheEnd - cacheStart).toFixed(2)}ms`);
console.log(`Média com cache: ${((cacheEnd - cacheStart) / 100).toFixed(3)}ms`);

console.log('\n✅ Testes manuais concluídos!');