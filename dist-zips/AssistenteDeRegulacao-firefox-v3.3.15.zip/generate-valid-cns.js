/**
 * Gerador de CNS válidos para testes
 * Gera CNS definitivos e provisórios válidos seguindo os algoritmos oficiais
 */

/**
 * Gera CNS definitivo válido
 * @param {string} prefix - Prefixo (1 ou 2)
 * @param {string} base - Base de 9 dígitos
 * @returns {string} CNS definitivo válido
 */
function generateDefinitiveCNS(prefix, base) {
  const cnsBase = prefix + base; // 10 dígitos
  
  let sum = 0;
  for (let i = 0; i < 11; i++) {
    sum += parseInt(cnsBase[i]) * (15 - i);
  }
  
  const remainder = sum % 11;
  let dv = 11 - remainder;
  
  if (dv === 11) {
    dv = 0;
  }
  
  if (dv === 10) {
    // Caso especial: soma 2 e recalcula
    sum += 2;
    const newRemainder = sum % 11;
    dv = 11 - newRemainder;
    if (dv === 11) dv = 0;
    return cnsBase + '0001';
  } else {
    // Caso normal
    const dvStr = dv.toString().padStart(2, '0');
    return cnsBase + dvStr + '00';
  }
}

/**
 * Gera CNS provisório tipo 9 válido
 * @param {string} base - Base de 14 dígitos iniciando com 9
 * @returns {string} CNS provisório tipo 9 válido
 */
function generateProvisionalCNS9(base) {
  let sum = 0;
  for (let i = 0; i < 14; i++) {
    sum += parseInt(base[i]) * (15 - i);
  }
  
  const remainder = sum % 11;
  const dv = remainder < 2 ? 0 : 11 - remainder;
  
  return base + dv.toString();
}

console.log('🧮 Gerando CNS válidos para testes...\n');

// CNS definitivos válidos
console.log('📋 CNS Definitivos Válidos:');
const cnsDefinitivo1 = generateDefinitiveCNS('1', '0000000000');
const cnsDefinitivo2 = generateDefinitiveCNS('2', '0000000000');
const cnsDefinitivo3 = generateDefinitiveCNS('1', '2345678901');
const cnsDefinitivo4 = generateDefinitiveCNS('2', '9876543210');

console.log(`CNS tipo 1: ${cnsDefinitivo1}`);
console.log(`CNS tipo 2: ${cnsDefinitivo2}`);
console.log(`CNS tipo 1 (variação): ${cnsDefinitivo3}`);
console.log(`CNS tipo 2 (variação): ${cnsDefinitivo4}`);

// CNS provisórios válidos
console.log('\n📋 CNS Provisórios Válidos:');
const cnsProvisorio7 = '712345678901234'; // Tipo 7 (sem validação de DV)
const cnsProvisorio8 = '812345678901234'; // Tipo 8 (sem validação de DV)
const cnsProvisorio9 = generateProvisionalCNS9('91234567890123');

console.log(`CNS tipo 7: ${cnsProvisorio7}`);
console.log(`CNS tipo 8: ${cnsProvisorio8}`);
console.log(`CNS tipo 9: ${cnsProvisorio9}`);

// Teste de validação
console.log('\n🧪 Testando CNS gerados:');

// Mock do CONFIG
global.CONFIG = {
  TIMEOUTS: {
    DEBOUNCE_SEARCH: 300
  }
};

// Importa a função de validação
import { validateCNS } from './validation.js';

const cnsToTest = [
  cnsDefinitivo1,
  cnsDefinitivo2,
  cnsDefinitivo3,
  cnsDefinitivo4,
  cnsProvisorio7,
  cnsProvisorio8,
  cnsProvisorio9
];

cnsToTest.forEach(cns => {
  const result = validateCNS(cns);
  console.log(`${cns}: ${result.valid ? '✅ VÁLIDO' : '❌ INVÁLIDO'} (${result.type || 'erro'})`);
  if (!result.valid) {
    console.log(`   Erro: ${result.message}`);
  }
});

console.log('\n📝 CNS para usar nos testes:');
console.log(`const validCNS = [`);
console.log(`  '${cnsDefinitivo1}', // CNS definitivo tipo 1`);
console.log(`  '${cnsDefinitivo2}', // CNS definitivo tipo 2`);
console.log(`  '${cnsDefinitivo3}', // CNS definitivo tipo 1 (variação)`);
console.log(`  '${cnsProvisorio7}', // CNS provisório tipo 7`);
console.log(`  '${cnsProvisorio8}', // CNS provisório tipo 8`);
console.log(`  '${cnsProvisorio9}'  // CNS provisório tipo 9`);
console.log(`];`);