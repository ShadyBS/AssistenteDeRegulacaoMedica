﻿/**
 * @file Gerenciador de Keep-Alive para manter a sessÃ£o ativa
 * Usa a API de alarmes para garantir funcionamento em Manifest V3
 */
import * as API from "./api.js";
import { getBrowserAPIInstance } from "./BrowserAPI.js";
import { createComponentLogger } from "./logger.js";

// Logger especÃ­fico para KeepAliveManager
const logger = createComponentLogger('KeepAliveManager');


export class KeepAliveManager {
  constructor() {
    this.isActive = false;
    this.intervalMinutes = 10; // PadrÃ£o: 10 minutos
    this.alarmName = "keepSessionAlive";
    this.api = getBrowserAPIInstance();
    
    this.init();
  }

  async init() {
    // Carrega as configuraÃ§Ãµes salvas
    await this.loadSettings();
    
    // Configura listener para alarmes
    this.setupAlarmListener();
    
    // Escuta mudanÃ§as nas configuraÃ§Ãµes
    this.api.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === "sync" && changes.keepSessionAliveInterval) {
        this.updateInterval(changes.keepSessionAliveInterval.newValue);
      }
    });
  }

  setupAlarmListener() {
    if (this.api.alarms) {
      this.api.alarms.onAlarm.addListener(async (alarm) => {
        if (alarm.name === this.alarmName) {
          try {
            const success = await API.keepSessionAlive();
            if (success) {
              logger.info(`[KeepAlive] Executado com sucesso (${new Date().toLocaleTimeString()})`);
            } else {
              logger.warn(`[KeepAlive] Falhou (${new Date().toLocaleTimeString()})`);
            }
          } catch (error) {
            logger.error("[KeepAlive] Erro durante execuÃ§Ã£o:", error);
          }
        }
      });
    }
  }

  async loadSettings() {
    try {
      const result = await this.api.storage.sync.get({
        keepSessionAliveInterval: 10
      });
      
      this.updateInterval(result.keepSessionAliveInterval);
    } catch (error) {
      logger.error("[KeepAlive] Erro ao carregar configuraÃ§Ãµes:", error);
    }
  }

  updateInterval(minutes) {
    const newMinutes = parseInt(minutes, 10) || 0;
    
    this.intervalMinutes = newMinutes;
    
    // Para o alarme atual
    this.stop();
    
    // Inicia novo alarme se o valor for maior que 0
    if (this.intervalMinutes > 0) {
      this.start();
    }
  }

  async start() {
    if (this.intervalMinutes <= 0) {
      logger.info("[KeepAlive] Desativado (intervalo = 0)");
      return;
    }

    if (this.isActive) {
      logger.info("[KeepAlive] JÃ¡ estÃ¡ ativo");
      return;
    }
    
    if (!this.api.alarms) {
      logger.error("[KeepAlive] API de alarmes nÃ£o disponÃ­vel - keep-alive nÃ£o funcionarÃ¡");
      return;
    }

    try {
      // Cria um alarme periÃ³dico
      await this.api.alarms.create(this.alarmName, {
        delayInMinutes: this.intervalMinutes,
        periodInMinutes: this.intervalMinutes
      });

      this.isActive = true;
      logger.info(`[KeepAlive] Iniciado: ${this.intervalMinutes} minutos usando alarmes`);
      
      // Executa imediatamente uma vez para testar
      try {
        const success = await API.keepSessionAlive();
        if (success) {
          logger.info(`[KeepAlive] ExecuÃ§Ã£o inicial bem-sucedida (${new Date().toLocaleTimeString()})`);
        } else {
          logger.warn(`[KeepAlive] ExecuÃ§Ã£o inicial falhou (${new Date().toLocaleTimeString()})`);
        }
      } catch (error) {
        logger.error("[KeepAlive] Erro na execuÃ§Ã£o inicial:", error);
      }
      
    } catch (error) {
      logger.error("[KeepAlive] Erro ao criar alarme:", error);
    }
  }

  async stop() {
    if (this.api.alarms) {
      try {
        await this.api.alarms.clear(this.alarmName);
      } catch (error) {
        logger.error("[KeepAlive] Erro ao limpar alarme:", error);
      }
    }
    
    this.isActive = false;
    logger.info("[KeepAlive] Parado");
  }

  async getStatus() {
    let nextExecution = null;
    
    if (this.isActive && this.api.alarms) {
      try {
        const alarm = await this.api.alarms.get(this.alarmName);
        if (alarm && alarm.scheduledTime) {
          nextExecution = new Date(alarm.scheduledTime);
        }
      } catch (error) {
        logger.error("[KeepAlive] Erro ao obter status do alarme:", error);
      }
    }
    
    return {
      isActive: this.isActive,
      intervalMinutes: this.intervalMinutes,
      nextExecution: nextExecution
    };
  }
}

